const toLib = require("./SS_VKSztaltna");

A = [
  40000, 80000, 120000, 160000, 200000, 240000, 280000, 320000, 360000, 400000,
  440000, 480000, 520000, 560000, 600000,
];

for (let i = 0; i < A.length; i++) {
  const result = toLib.toExport(A[i]);
}
